package com.gcu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Topic51ApplicationTests {

	@Test
	void contextLoads() {
	}

}
