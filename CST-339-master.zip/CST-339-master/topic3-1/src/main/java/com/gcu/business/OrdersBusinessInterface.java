package com.gcu.business;

import java.util.ArrayList;
import java.util.List;

import com.gcu.model.OrderModel;

public interface OrdersBusinessInterface {
	
	public void test();
	
	public ArrayList<OrderModel> getOrders();
	
	

}
