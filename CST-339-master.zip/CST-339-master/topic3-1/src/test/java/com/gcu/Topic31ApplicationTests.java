package com.gcu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Topic31ApplicationTests {

	@Test
	void contextLoads() {
	}

}
