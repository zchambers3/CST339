package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic72cApplication {

	public static void main(String[] args) {
		SpringApplication.run(Topic72cApplication.class, args);
	}

}
