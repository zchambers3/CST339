package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic71bApplication {

	public static void main(String[] args) {
		SpringApplication.run(Topic71bApplication.class, args);
	}

}
