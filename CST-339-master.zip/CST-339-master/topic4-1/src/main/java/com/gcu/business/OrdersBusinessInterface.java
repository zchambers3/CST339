package com.gcu.business;




import java.util.ArrayList;

import com.gcu.model.OrderModel;

public interface OrdersBusinessInterface {
	
	public void test();
	
	public ArrayList<OrderModel> getOrders();
	
	
	public void init();
	
	public void destroy();
	
	

}
