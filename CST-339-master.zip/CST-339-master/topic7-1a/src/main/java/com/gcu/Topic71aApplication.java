package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic71aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Topic71aApplication.class, args);
	}

}
