package com.gcu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Topic71cApplication {

	public static void main(String[] args) {
		SpringApplication.run(Topic71cApplication.class, args);
	}

}
